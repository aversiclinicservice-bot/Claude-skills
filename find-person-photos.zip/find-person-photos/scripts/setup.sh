#!/usr/bin/env bash
# One-time setup per session: Python deps + face models (~190 MB after unzip).
set -e
MODEL_DIR="${FACE_MODEL_DIR:-$HOME/.cache/face-models/buffalo_l}"

python3 -c "import onnxruntime" 2>/dev/null || pip install --break-system-packages -q onnxruntime
python3 -c "import cv2" 2>/dev/null || pip install --break-system-packages -q opencv-python-headless
python3 -c "import PIL" 2>/dev/null || pip install --break-system-packages -q pillow

if [ -f "$MODEL_DIR/det_10g.onnx" ] && [ -f "$MODEL_DIR/w600k_r50.onnx" ]; then
  echo "models already present: $MODEL_DIR"
else
  mkdir -p "$MODEL_DIR"
  TMP="$(mktemp -d)"
  echo "downloading InsightFace buffalo_l models from GitHub releases..."
  curl -fsSL --retry 3 --max-time 600 -o "$TMP/buffalo_l.zip" \
    https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip
  unzip -o -q "$TMP/buffalo_l.zip" det_10g.onnx w600k_r50.onnx -d "$MODEL_DIR"
  rm -rf "$TMP"
fi
ls -la "$MODEL_DIR"
echo "setup OK"
