#!/usr/bin/env python3
"""Turn a device_list_dir result into batches of image paths for device_stage_files.

When a recursive listing is too long to show inline, the tool saves it to a file
(the error message gives the path). Point this script at that file:

  pick_images.py --listing /root/.claude/.../tool-results/xxx.txt \
                 --root "C:\\Users\\name\\Downloads" [--skip-dir "ლაშა ბაქრაძე"]

Prints JSON: counts, cloud-only files that were skipped, and "batches" (lists of
<=50 absolute device paths, <=450 MB each) to pass to device_stage_files.
"""
import argparse
import json
import os

IMAGE_EXTS = {".jpg", ".jpeg", ".jfif", ".png", ".webp", ".bmp", ".tif", ".tiff",
              ".gif", ".heic", ".heif", ".avif"}
SKIP_DIRS = {"appdata", "node_modules", ".git", "$recycle.bin", "gadasamowmebeli",
             "გადასამოწმებელი", "claude-skills"}
MIN_BYTES = 3_000
MAX_NOEXT_BYTES = 20_000_000  # extensionless files bigger than this are rarely photos


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--listing", required=True, help="file holding the device_list_dir JSON")
    ap.add_argument("--root", required=True, help="the path that was listed")
    ap.add_argument("--skip-dir", action="append", default=[], help="folder name to skip")
    ap.add_argument("--include-cloud", action="store_true", help="also stage cloud-only files")
    args = ap.parse_args()

    raw = open(args.listing, encoding="utf-8").read()
    data = json.loads(raw[raw.index("{"):])
    skip = SKIP_DIRS | {s.lower() for s in args.skip_dir}
    win = "\\" in args.root or (len(args.root) > 1 and args.root[1] == ":")
    sep = "\\" if win else "/"

    picked, cloud, capped, noext = [], [], [], 0
    for e in data.get("entries", []):
        name = e["name"]
        parts = name.split("/")
        if any(p.lower() in skip or (p.startswith(".") and p != ".") for p in parts[:-1]):
            continue
        if e.get("depthCapped"):
            capped.append(name)
        if e.get("type") != "file" or e.get("protected"):
            continue
        ext = os.path.splitext(parts[-1])[1].lower()
        size = e.get("size", 0)
        is_img = ext in IMAGE_EXTS
        if not is_img and ext == "" and MIN_BYTES <= size <= MAX_NOEXT_BYTES and not parts[-1].startswith("."):
            is_img = True
            noext += 1
        if not is_img or size < MIN_BYTES:
            continue
        path = args.root.rstrip("\\/") + sep + name.replace("/", sep)
        if e.get("cloudOnly") and not args.include_cloud:
            cloud.append(path)
            continue
        picked.append((path, size))

    batches, cur, cur_b = [], [], 0
    for path, size in picked:
        if cur and (len(cur) >= 50 or cur_b + size > 450_000_000):
            batches.append(cur)
            cur, cur_b = [], 0
        cur.append(path)
        cur_b += size
    if cur:
        batches.append(cur)
    print(json.dumps({
        "images": len(picked), "of_which_no_extension": noext,
        "total_mb": round(sum(s for _, s in picked) / 1e6, 1),
        "truncated_listing": bool(data.get("truncated")),
        "depth_capped_dirs": capped, "cloud_only_skipped": cloud, "batches": batches,
    }, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
