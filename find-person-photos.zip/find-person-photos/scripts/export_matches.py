#!/usr/bin/env python3
"""Copy the found photos into an output folder and plan the copy back to the computer.

  export_matches.py --work WORK --device-dest "C:\\Users\\me\\Desktop\\ირაკლი"

- tier "match"                      -> OUT/<file>
- tier "to_check" / "uncertain"     -> OUT/<check-subfolder>/<file>   (unless --no-check-folder)
- identical files (same content) are copied once
- name clashes get " (2)", " (3)" ...

Writes WORK/commit_batches.json: a list of batches, each a list of
{"stagedPath", "devicePath"} with at most 50 files and ~90 MB per batch, ready
for device_commit_files. Also lists photos whose staged copy is missing
(deleted to save disk) so they can be re-staged first.
"""
import argparse
import json
import os
import shutil

CHECK_SUBFOLDER = "გადასამოწმებელი"  # "to double-check"


def device_join(root, *parts):
    win = "\\" in root or (len(root) > 1 and root[1] == ":")
    sep = "\\" if win else "/"
    return sep.join([root.rstrip("\\/")] + [p.replace("/", sep) for p in parts])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True)
    ap.add_argument("--device-dest", required=True, help="destination folder on the user's computer")
    ap.add_argument("--out", help="local output folder (default /mnt/user-data/outputs/<name>)")
    ap.add_argument("--no-check-folder", action="store_true",
                    help="leave uncertain / to_check photos out entirely")
    ap.add_argument("--check-subfolder", default=CHECK_SUBFOLDER)
    args = ap.parse_args()

    args.work = os.path.abspath(args.work)
    with open(os.path.join(args.work, "results.json"), encoding="utf-8") as f:
        res = json.load(f)
    name = res.get("name") or "found"
    out = args.out or os.path.join("/mnt/user-data/outputs", name)
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out, exist_ok=True)

    plan, missing, used = [], [], set()
    for p in res["photos"]:
        if p["tier"] == "match":
            sub = None
        elif p["tier"] in ("to_check", "uncertain") and not args.no_check_folder:
            sub = args.check_subfolder
        else:
            continue
        src = p["local_path"]
        if not os.path.exists(src):
            missing.append(p["device_path"] or src)
            continue
        base = os.path.basename(src)
        stem, ext = os.path.splitext(base)
        cand, k = base, 2
        while (sub, cand.lower()) in used:
            cand = f"{stem} ({k}){ext}"
            k += 1
        used.add((sub, cand.lower()))
        local_dir = os.path.join(out, sub) if sub else out
        os.makedirs(local_dir, exist_ok=True)
        dst = os.path.join(local_dir, cand)
        shutil.copy2(src, dst)
        dev = device_join(args.device_dest, *( [sub, cand] if sub else [cand] ))
        plan.append({"stagedPath": dst, "devicePath": dev, "bytes": os.path.getsize(dst),
                     "tier": p["tier"], "from": p["device_path"]})

    batches, cur, cur_bytes = [], [], 0
    for item in plan:
        if cur and (len(cur) >= 50 or cur_bytes + item["bytes"] > 90_000_000):
            batches.append(cur)
            cur, cur_bytes = [], 0
        cur.append({"stagedPath": item["stagedPath"], "devicePath": item["devicePath"]})
        cur_bytes += item["bytes"]
    if cur:
        batches.append(cur)

    with open(os.path.join(args.work, "commit_batches.json"), "w", encoding="utf-8") as f:
        json.dump(batches, f, ensure_ascii=False, indent=1)
    with open(os.path.join(args.work, "export_plan.json"), "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=1)
    summary = {
        "local_out": out,
        "matches": sum(1 for x in plan if x["tier"] == "match"),
        "to_check": sum(1 for x in plan if x["tier"] != "match"),
        "batches": len(batches),
        "commit_batches_file": os.path.join(args.work, "commit_batches.json"),
        "missing_staged_copies": missing,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
