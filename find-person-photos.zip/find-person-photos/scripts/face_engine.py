"""Face detection + recognition engine (InsightFace buffalo_l models via onnxruntime).

- Detector:  SCRFD det_10g  -> boxes + 5 facial landmarks
- Recognizer: ArcFace w600k_r50 -> 512-d embedding (L2-normalised)

Cosine similarity between two embeddings is a plain dot product.
Rough guide for this model: same person usually > 0.40, strangers usually < 0.20.
"""
import os
import subprocess
import tempfile
import warnings

import cv2
import numpy as np
from PIL import Image, ImageOps

warnings.filterwarnings("ignore")
Image.MAX_IMAGE_PIXELS = 300_000_000

MODEL_DIR = os.environ.get(
    "FACE_MODEL_DIR", os.path.expanduser("~/.cache/face-models/buffalo_l")
)

IMAGE_EXTS = {
    ".jpg", ".jpeg", ".jfif", ".png", ".webp", ".bmp", ".tif", ".tiff",
    ".gif", ".heic", ".heif", ".avif",
}

ARCFACE_DST = np.array(
    [[38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
     [41.5493, 92.3655], [70.7299, 92.2041]], dtype=np.float32)


# ----------------------------------------------------------------------------
# Image loading
# ----------------------------------------------------------------------------
def load_image(path, max_side=3000):
    """Return (bgr ndarray, (orig_w, orig_h)). EXIF rotation is applied.
    Very large images are downscaled to max_side for speed."""
    ext = os.path.splitext(path)[1].lower()
    img = None
    try:
        img = Image.open(path)
        if img.format == "JPEG":
            img.draft("RGB", (max_side, max_side))
        if getattr(img, "is_animated", False):
            img.seek(0)
        img = ImageOps.exif_transpose(img)
    except Exception:
        img = None
    if img is None and ext in {".heic", ".heif", ".avif"}:
        img = _load_via_imagemagick(path)
    if img is None:
        raise ValueError("unreadable image")
    orig = img.size
    img = img.convert("RGB")
    w, h = img.size
    s = max(w, h)
    if s > max_side:
        r = max_side / s
        img = img.resize((max(1, int(w * r)), max(1, int(h * r))), Image.LANCZOS)
    arr = np.asarray(img)[:, :, ::-1].copy()  # RGB -> BGR
    return arr, orig


def _load_via_imagemagick(path):
    try:
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as t:
            tmp = t.name
        subprocess.run(["convert", path + "[0]", "-auto-orient", tmp],
                       check=True, capture_output=True, timeout=120)
        im = Image.open(tmp)
        im.load()
        os.unlink(tmp)
        return im
    except Exception:
        return None


# ----------------------------------------------------------------------------
# Detector (SCRFD)
# ----------------------------------------------------------------------------
def _nms(dets, thresh=0.4):
    x1, y1, x2, y2, scores = dets[:, 0], dets[:, 1], dets[:, 2], dets[:, 3], dets[:, 4]
    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        order = order[np.where(ovr <= thresh)[0] + 1]
    return keep


class Detector:
    def __init__(self, model_path, threads=0):
        import onnxruntime as ort
        so = ort.SessionOptions()
        if threads:
            so.intra_op_num_threads = threads
        so.log_severity_level = 3
        self.sess = ort.InferenceSession(model_path, so, providers=["CPUExecutionProvider"])
        self.input_name = self.sess.get_inputs()[0].name
        self.output_names = [o.name for o in self.sess.get_outputs()]
        self.strides = [8, 16, 32]
        self.num_anchors = 2
        self._centers = {}

    def _anchor_centers(self, h, w, stride):
        key = (h, w, stride)
        if key not in self._centers:
            c = np.stack(np.mgrid[:h, :w][::-1], axis=-1).astype(np.float32)
            c = (c * stride).reshape((-1, 2))
            c = np.stack([c] * self.num_anchors, axis=1).reshape((-1, 2))
            self._centers[key] = c
        return self._centers[key]

    def detect(self, img, det_size=640, thresh=0.5):
        """Return list of dicts: bbox [x1,y1,x2,y2], score, kps (5x2) in img coords."""
        h, w = img.shape[:2]
        scale = det_size / max(h, w)
        nw, nh = int(round(w * scale)), int(round(h * scale))
        resized = cv2.resize(img, (nw, nh))
        canvas = np.zeros((det_size, det_size, 3), dtype=np.uint8)
        canvas[:nh, :nw] = resized
        blob = cv2.dnn.blobFromImage(canvas, 1.0 / 128.0, (det_size, det_size),
                                     (127.5, 127.5, 127.5), swapRB=True)
        outs = self.sess.run(self.output_names, {self.input_name: blob})
        outs = [o[0] if o.ndim == 3 else o for o in outs]
        fmc = 3
        scores_l, boxes_l, kps_l = [], [], []
        for idx, stride in enumerate(self.strides):
            scores = outs[idx].reshape(-1)
            bbox = outs[idx + fmc] * stride
            kps = outs[idx + fmc * 2] * stride
            fh, fw = det_size // stride, det_size // stride
            centers = self._anchor_centers(fh, fw, stride)
            pos = np.where(scores >= thresh)[0]
            if pos.size == 0:
                continue
            c = centers[pos]
            b = bbox[pos]
            boxes = np.stack([c[:, 0] - b[:, 0], c[:, 1] - b[:, 1],
                              c[:, 0] + b[:, 2], c[:, 1] + b[:, 3]], axis=-1)
            k = kps[pos]
            pts = np.stack([c[:, i % 2] + k[:, i] for i in range(10)], axis=-1)
            scores_l.append(scores[pos])
            boxes_l.append(boxes)
            kps_l.append(pts.reshape(-1, 5, 2))
        if not scores_l:
            return []
        scores = np.concatenate(scores_l)
        boxes = np.concatenate(boxes_l) / scale
        kpss = np.concatenate(kps_l) / scale
        dets = np.hstack([boxes, scores[:, None]]).astype(np.float32)
        keep = _nms(dets, 0.4)
        res = []
        for i in keep:
            x1, y1, x2, y2 = boxes[i]
            res.append({
                "bbox": [float(max(0, x1)), float(max(0, y1)), float(min(w, x2)), float(min(h, y2))],
                "score": float(scores[i]),
                "kps": kpss[i].astype(np.float32),
            })
        return res


# ----------------------------------------------------------------------------
# Recognizer (ArcFace)
# ----------------------------------------------------------------------------
def align_face(img, kps, size=112):
    M, _ = cv2.estimateAffinePartial2D(kps.astype(np.float32), ARCFACE_DST, method=cv2.LMEDS)
    if M is None:
        M = cv2.getAffineTransform(kps[:3].astype(np.float32), ARCFACE_DST[:3])
    return cv2.warpAffine(img, M, (size, size), borderValue=0.0)


class Recognizer:
    def __init__(self, model_path, threads=0):
        import onnxruntime as ort
        so = ort.SessionOptions()
        if threads:
            so.intra_op_num_threads = threads
        so.log_severity_level = 3
        self.sess = ort.InferenceSession(model_path, so, providers=["CPUExecutionProvider"])
        self.input_name = self.sess.get_inputs()[0].name
        self.output_name = self.sess.get_outputs()[0].name
        self.mean, self.std = 127.5, 127.5

    def embed(self, aligned_faces):
        """aligned_faces: list of 112x112 BGR arrays -> (N,512) normalised float32."""
        if not aligned_faces:
            return np.zeros((0, 512), np.float32)
        out = []
        for i in range(0, len(aligned_faces), 32):
            chunk = aligned_faces[i:i + 32]
            blob = cv2.dnn.blobFromImages(chunk, 1.0 / self.std, (112, 112),
                                          (self.mean,) * 3, swapRB=True)
            out.append(self.sess.run([self.output_name], {self.input_name: blob})[0])
        emb = np.concatenate(out).astype(np.float32)
        emb /= np.linalg.norm(emb, axis=1, keepdims=True) + 1e-9
        return emb


# ----------------------------------------------------------------------------
# High-level helper
# ----------------------------------------------------------------------------
class FaceEngine:
    def __init__(self, model_dir=MODEL_DIR, threads=0):
        det = os.path.join(model_dir, "det_10g.onnx")
        rec = os.path.join(model_dir, "w600k_r50.onnx")
        for p in (det, rec):
            if not os.path.exists(p):
                raise SystemExit(f"Model missing: {p}\nRun scripts/setup.sh first.")
        self.detector = Detector(det, threads)
        self.recognizer = Recognizer(rec, threads)

    def analyze(self, img, det_size=None, thresh=0.5):
        """Detect + embed all faces in a BGR image.
        Returns list of dicts with bbox, score, kps, size (px), emb, crop (BGR thumbnail)."""
        h, w = img.shape[:2]
        if det_size:
            faces = self.detector.detect(img, det_size=det_size, thresh=thresh)
        else:
            # 640 catches normal/close-up faces; big photos get a second 1280 pass
            # so small faces in group shots are found too. Merge with NMS.
            faces = self.detector.detect(img, det_size=640, thresh=thresh)
            if max(h, w) >= 1400:
                faces += self.detector.detect(img, det_size=1280, thresh=thresh)
                faces = _merge(faces)
        if not faces:
            return []
        aligned = [align_face(img, f["kps"]) for f in faces]
        embs = self.recognizer.embed(aligned)
        for f, e in zip(faces, embs):
            x1, y1, x2, y2 = f["bbox"]
            f["size"] = float(min(x2 - x1, y2 - y1))
            f["emb"] = e
            f["crop"] = context_crop(img, f["bbox"])
        return faces


def _merge(faces, thresh=0.4):
    if len(faces) < 2:
        return faces
    dets = np.array([f["bbox"] + [f["score"]] for f in faces], dtype=np.float32)
    return [faces[i] for i in _nms(dets, thresh)]


def context_crop(img, bbox, out=160, pad=0.45):
    """Square crop around a face with some context, resized to out x out."""
    h, w = img.shape[:2]
    x1, y1, x2, y2 = bbox
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    side = max(x2 - x1, y2 - y1) * (1 + 2 * pad)
    a, b = int(cx - side / 2), int(cy - side / 2)
    c, d = int(cx + side / 2), int(cy + side / 2)
    crop = np.zeros((d - b, c - a, 3), np.uint8)
    sa, sb, sc, sd = max(a, 0), max(b, 0), min(c, w), min(d, h)
    if sc > sa and sd > sb:
        crop[sb - b:sd - b, sa - a:sc - a] = img[sb:sd, sa:sc]
    return cv2.resize(crop, (out, out), interpolation=cv2.INTER_AREA)
