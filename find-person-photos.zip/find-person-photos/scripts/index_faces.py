#!/usr/bin/env python3
"""Index every face in a set of photo folders into a SQLite database.

Incremental: files already indexed (same path + size) are skipped, so you can
stage more photos and run it again.

Usage:
  python3 index_faces.py --db /home/claude/face-index/index.db \
      --root "/mnt/user-data/uploads/Desktop=C:\\Users\\me\\Desktop" \
      --root "/mnt/user-data/uploads/Pictures=C:\\Users\\me\\Pictures"

Each --root is LOCAL_DIR[=DEVICE_DIR]. DEVICE_DIR is the matching folder on the
user's computer; it is used to remember each photo's original location.
"""
import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time

import cv2
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from face_engine import IMAGE_EXTS, FaceEngine, load_image  # noqa: E402

MIN_BYTES = 3_000  # skip icons; small WhatsApp-style images are still kept
MIN_SIDE = 64      # images smaller than this (px) cannot hold a usable face

SCHEMA = """
CREATE TABLE IF NOT EXISTS files(
  id INTEGER PRIMARY KEY, local_path TEXT UNIQUE, device_path TEXT,
  size INTEGER, sha1 TEXT, width INTEGER, height INTEGER,
  n_faces INTEGER, error TEXT, indexed_at REAL);
CREATE TABLE IF NOT EXISTS faces(
  id INTEGER PRIMARY KEY, file_id INTEGER, x1 REAL, y1 REAL, x2 REAL, y2 REAL,
  score REAL, size REAL, emb BLOB, crop TEXT);
CREATE INDEX IF NOT EXISTS faces_file ON faces(file_id);
"""


def device_join(root, rel):
    if not root:
        return None
    win = "\\" in root or (len(root) > 1 and root[1] == ":")
    sep = "\\" if win else "/"
    rel = rel.replace("/", sep)
    return root.rstrip("\\/") + sep + rel


def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_images(local_root, exclude):
    exclude = set(exclude) | {"claude-skills"}  # this skill's own scripts folder
    for dirpath, dirnames, filenames in os.walk(local_root):
        dirnames[:] = [d for d in dirnames if d not in exclude and not d.startswith(".")]
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            # Files saved without an extension are often images (e.g. "eka uglava").
            if ext in IMAGE_EXTS or (ext == "" and not fn.startswith(".")):
                yield os.path.join(dirpath, fn)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--root", action="append", required=True,
                    help="LOCAL_DIR[=DEVICE_DIR]; repeatable")
    ap.add_argument("--exclude", action="append", default=[],
                    help="folder name to skip (repeatable)")
    ap.add_argument("--det-size", type=int, default=None,
                    help="fixed detector size (default: auto multi-scale)")
    ap.add_argument("--threads", type=int, default=0)
    args = ap.parse_args()

    db_dir = os.path.dirname(os.path.abspath(args.db))
    crops_dir = os.path.join(db_dir, "crops")
    os.makedirs(crops_dir, exist_ok=True)
    con = sqlite3.connect(args.db)
    con.executescript(SCHEMA)
    known = {r[0]: r[1] for r in con.execute("SELECT local_path, size FROM files")}

    todo = []
    for spec in args.root:
        local, _, device = spec.partition("=")
        local = os.path.abspath(local)
        if not os.path.isdir(local):
            print(f"WARNING: not a folder, skipped: {local}")
            continue
        for p in iter_images(local, set(args.exclude)):
            try:
                sz = os.path.getsize(p)
            except OSError:
                continue
            if sz < MIN_BYTES or known.get(p) == sz:
                continue
            rel = os.path.relpath(p, local)
            todo.append((p, device_join(device, rel), sz))

    print(f"{len(todo)} new image(s) to index ({len(known)} already in index)")
    if not todo:
        return
    eng = FaceEngine(threads=args.threads)
    t0 = time.time()
    n_faces_total = 0
    errors = 0
    for i, (p, dev, sz) in enumerate(todo, 1):
        con.execute("DELETE FROM faces WHERE file_id IN (SELECT id FROM files WHERE local_path=?)", (p,))
        con.execute("DELETE FROM files WHERE local_path=?", (p,))
        try:
            img, (ow, oh) = load_image(p)
            faces = [] if min(ow, oh) < MIN_SIDE else eng.analyze(img, det_size=args.det_size)
            # Report sizes in original-pixel units (image may have been downscaled)
            k = max(ow, oh) / max(img.shape[:2])
            cur = con.execute(
                "INSERT INTO files(local_path, device_path, size, sha1, width, height, n_faces, error, indexed_at)"
                " VALUES(?,?,?,?,?,?,?,?,?)",
                (p, dev, sz, sha1_of(p), ow, oh, len(faces), None, time.time()))
            fid = cur.lastrowid
            for f in faces:
                x1, y1, x2, y2 = f["bbox"]
                cur = con.execute(
                    "INSERT INTO faces(file_id, x1, y1, x2, y2, score, size, emb, crop) VALUES(?,?,?,?,?,?,?,?,?)",
                    (fid, x1, y1, x2, y2, f["score"], f["size"] * k,
                     f["emb"].astype(np.float32).tobytes(), None))
                crop_path = os.path.join(crops_dir, f"{cur.lastrowid}.jpg")
                cv2.imwrite(crop_path, f["crop"], [cv2.IMWRITE_JPEG_QUALITY, 88])
                con.execute("UPDATE faces SET crop=? WHERE id=?", (crop_path, cur.lastrowid))
            n_faces_total += len(faces)
        except Exception as e:  # keep going on bad files
            errors += 1
            con.execute(
                "INSERT INTO files(local_path, device_path, size, n_faces, error, indexed_at) VALUES(?,?,?,?,?,?)",
                (p, dev, sz, 0, str(e)[:200], time.time()))
        if i % 25 == 0 or i == len(todo):
            con.commit()
            el = time.time() - t0
            print(f"  {i}/{len(todo)} images, {n_faces_total} faces, {errors} errors, "
                  f"{el:.0f}s elapsed, ~{el / i * (len(todo) - i):.0f}s left", flush=True)
    con.commit()
    tot_files, tot_faces = con.execute(
        "SELECT (SELECT COUNT(*) FROM files), (SELECT COUNT(*) FROM faces)").fetchone()
    print(json.dumps({"indexed_now": len(todo), "faces_now": n_faces_total, "errors_now": errors,
                      "index_files_total": tot_files, "index_faces_total": tot_faces}))


if __name__ == "__main__":
    main()
