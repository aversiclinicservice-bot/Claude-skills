#!/usr/bin/env python3
"""Find every indexed photo that contains the person shown in a reference photo.

How it works
  1. The reference face is compared with every face in the index (cosine similarity).
  2. Self-expansion: faces that match very strongly (>= --seed) are added as extra
     references, and the search repeats. This lets the search learn how the person
     looks from other angles / lighting / ages, starting from a single photo.
     A guard (--anchor) stops it drifting to a look-alike: a new seed must still
     resemble the original reference (or a confirmed face) at least a little.
  3. Photos are sorted into tiers:
       match      score >= --match           (very likely the person)
       uncertain  --low <= score < --match   (needs a visual check)
     Contact sheets of uncertain faces (and the weakest matches) are written to
     WORK/sheets so they can be checked by eye.
  4. Visual decisions are fed back with --confirm / --reject / --unsure (face ids
     printed on the sheets). Confirmed faces become references too, so each
     re-run can find more. Decisions are saved in WORK/decisions.json and
     accumulate across runs.

Usage
  first run:  find_person.py --db DB --work WORK --name NAME --ref /path/ref.jpg
  re-runs:    find_person.py --db DB --work WORK --confirm 12,40 --reject 7 --unsure 33
"""
import argparse
import json
import math
import os
import sqlite3
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from face_engine import FaceEngine, context_crop, load_image  # noqa: E402

FONT_PATHS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]


def font(size):
    for p in FONT_PATHS:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def parse_ids(s):
    out = []
    for part in (s or "").replace(" ", "").split(","):
        if part:
            out.append(int(part.lstrip("#")))
    return out


def load_json(path, default):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return default


def save_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


# ----------------------------------------------------------------------------
def setup_reference(args, work):
    """Embed the reference photo(s). Saves ref_embs.npy + ref crops in WORK.

    One reference: the largest face is used (warns if another face is similar in size).
    Several references: in each photo, the face that best matches the faces chosen in
    the other photos is used, so a bigger stranger in a group shot is not picked.
    """
    eng = FaceEngine()
    notes, all_faces = [], []
    for ref in args.ref:
        img, _ = load_image(ref)
        faces = eng.analyze(img)
        if not faces:
            raise SystemExit(f"NO_FACE: no face found in reference photo {ref}. "
                             "Ask the user for a clearer photo where the face is visible.")
        faces.sort(key=lambda f: -f["size"])
        all_faces.append(faces)
    n = len(all_faces)
    picks = [0] * n
    if args.ref_face:
        for ri, faces in enumerate(all_faces):
            if args.ref_face > len(faces):
                raise SystemExit(f"--ref-face {args.ref_face} but only {len(faces)} faces in {args.ref[ri]}")
        picks = [args.ref_face - 1] * n
    elif n > 1:
        for _ in range(3):  # consensus: each pick should agree with the others
            for i in range(n):
                others = np.stack([all_faces[j][picks[j]]["emb"] for j in range(n) if j != i])
                agree = [float((others @ f["emb"]).mean()) for f in all_faces[i]]
                picks[i] = int(np.argmax(agree))
        for i in range(n):
            others = np.stack([all_faces[j][picks[j]]["emb"] for j in range(n) if j != i])
            agree = float((others @ all_faces[i][picks[i]]["emb"]).mean())
            if picks[i] != 0:
                notes.append(f"REF_FACE_CHOSEN in {args.ref[i]}: used face {picks[i] + 1} (not the largest), "
                             f"because it matches the other reference photos (agreement {agree:.2f}).")
            if agree < 0.30:
                notes.append(f"INCONSISTENT_REF: {args.ref[i]} does not look like the other reference "
                             f"photos (agreement {agree:.2f}). Check ref_crop_{i + 1}.jpg; drop it or ask the user.")
    elif len(all_faces[0]) > 1 and all_faces[0][1]["size"] >= 0.6 * all_faces[0][0]["size"]:
        faces = all_faces[0]
        sheet = os.path.join(work, "ref_faces_1.jpg")
        make_sheet([(f"face {i + 1}", f["crop"]) for i, f in enumerate(faces[:12])],
                   sheet, title="Faces in the reference photo")
        notes.append(f"MULTIPLE_FACES in {args.ref[0]}: {len(faces)} faces of similar size. "
                     f"Using the largest (face 1). Check {sheet}; if the wrong person "
                     f"was picked, re-run with --ref-face N.")
    embs, crops = [], []
    for faces, pick in zip(all_faces, picks):
        f = faces[pick]
        embs.append(f["emb"])
        crops.append(f["crop"])
        if f["size"] < 60:
            notes.append(f"SMALL_REF_FACE: reference face is only {int(f['size'])}px wide; "
                         "results will be less reliable. A closer photo would help.")
    for old in os.listdir(work):
        if old.startswith("ref_crop_"):
            os.remove(os.path.join(work, old))
    for i, c in enumerate(crops):
        cv2.imwrite(os.path.join(work, f"ref_crop_{i + 1}.jpg"), c)
    np.save(os.path.join(work, "ref_embs.npy"), np.stack(embs).astype(np.float32))
    return notes


def make_sheet(items, out_path, title="", ref_crops=None, cols=6, cell=160):
    """items: list of (label, bgr_crop). ref_crops shown in the first row."""
    ref_crops = ref_crops or []
    lab_h, head_h = 26, 34 if title else 0
    rows = math.ceil(len(items) / cols) + (1 if ref_crops else 0)
    W, H = cols * cell, head_h + rows * (cell + lab_h)
    sheet = Image.new("RGB", (W, H), (255, 255, 255))
    d = ImageDraw.Draw(sheet)
    if title:
        d.text((8, 6), title, fill=(0, 0, 0), font=font(18))
    y0 = head_h
    cells = []
    if ref_crops:
        for i, c in enumerate(ref_crops[:cols]):
            cells.append((i, 0, f"REFERENCE {i + 1}", c, (0, 110, 0)))
    r0 = 1 if ref_crops else 0
    for k, (label, c) in enumerate(items):
        cells.append((k % cols, r0 + k // cols, label, c, (0, 0, 0)))
    for col, row, label, c, color in cells:
        x, y = col * cell, y0 + row * (cell + lab_h)
        im = Image.fromarray(cv2.cvtColor(c, cv2.COLOR_BGR2RGB)).resize((cell - 4, cell - 4))
        sheet.paste(im, (x + 2, y + 2))
        if color != (0, 0, 0):
            d.rectangle([x + 1, y + 1, x + cell - 2, y + cell - 2], outline=color, width=3)
        d.text((x + 4, y + cell + 2), label, fill=color, font=font(15))
    sheet.save(out_path, quality=90)


def crop_for(face_row):
    p = face_row["crop"]
    if p and os.path.exists(p):
        return cv2.imread(p)
    # fall back to the staged file
    img, _ = load_image(face_row["local_path"])
    return context_crop(img, [face_row["x1"], face_row["y1"], face_row["x2"], face_row["y2"]])


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--work", required=True, help="working folder for this search")
    ap.add_argument("--name", help="person / output folder name")
    ap.add_argument("--ref", action="append", help="reference photo (repeatable)")
    ap.add_argument("--ref-face", type=int, help="which face in the reference (1 = largest)")
    ap.add_argument("--confirm", help="face ids that ARE the person")
    ap.add_argument("--reject", help="face ids that are NOT the person")
    ap.add_argument("--unsure", help="face ids that cannot be decided visually")
    ap.add_argument("--match", type=float, default=0.42)
    ap.add_argument("--low", type=float, default=0.26)
    ap.add_argument("--seed", type=float, default=0.50)
    ap.add_argument("--anchor", type=float, default=0.30)
    ap.add_argument("--rounds", type=int, default=8)
    ap.add_argument("--check-below", type=float, default=0.55,
                    help="matches below this score also get a review sheet")
    ap.add_argument("--min-seed-size", type=float, default=50)
    ap.add_argument("--near-floor", type=float, default=0.12,
                    help="near-miss sheet shows faces between this and --low")
    ap.add_argument("--near-max", type=int, default=12)
    ap.add_argument("--check-ref", action="store_true",
                    help="only process the reference photo(s) and report; no search")
    args = ap.parse_args()

    work = os.path.abspath(args.work)
    os.makedirs(os.path.join(work, "sheets"), exist_ok=True)
    meta = load_json(os.path.join(work, "meta.json"), {})
    if args.name:
        meta["name"] = args.name
    notes = []
    if args.ref:
        notes += setup_reference(args, work)
        meta["refs"] = [os.path.abspath(r) for r in args.ref]
    save_json(os.path.join(work, "meta.json"), meta)
    if args.check_ref:
        crops = sorted(f for f in os.listdir(work) if f.startswith(("ref_crop_", "ref_faces_")))
        print(json.dumps({"ok": True, "notes": notes,
                          "files": [os.path.join(work, f) for f in crops]}, ensure_ascii=False, indent=1))
        return
    ref_path = os.path.join(work, "ref_embs.npy")
    if not os.path.exists(ref_path):
        raise SystemExit("No reference yet: pass --ref /path/to/photo.jpg")
    ref_embs = np.load(ref_path)
    ref_crops = [cv2.imread(os.path.join(work, f"ref_crop_{i + 1}.jpg")) for i in range(len(ref_embs))]

    dec_path = os.path.join(work, "decisions.json")
    dec = load_json(dec_path, {"confirm": [], "reject": [], "unsure": []})
    for key, val in (("confirm", args.confirm), ("reject", args.reject), ("unsure", args.unsure)):
        for fid in parse_ids(val):
            for other in dec:
                if fid in dec[other]:
                    dec[other].remove(fid)
            dec[key].append(fid)
    save_json(dec_path, dec)
    confirmed, rejected, unsure = set(dec["confirm"]), set(dec["reject"]), set(dec["unsure"])

    # ---- load index --------------------------------------------------------
    con = sqlite3.connect(args.db)
    con.row_factory = sqlite3.Row
    rows = con.execute(
        "SELECT faces.id AS face_id, faces.file_id, x1, y1, x2, y2, faces.score AS det, faces.size,"
        " emb, crop, files.local_path, files.device_path, files.sha1, files.width, files.height"
        " FROM faces JOIN files ON files.id = faces.file_id").fetchall()
    if not rows:
        raise SystemExit("Index is empty: run index_faces.py first.")
    face_ids = np.array([r["face_id"] for r in rows])
    E = np.stack([np.frombuffer(r["emb"], dtype=np.float32) for r in rows])
    size = np.array([r["size"] for r in rows])
    det = np.array([r["det"] for r in rows])
    pos = {fid: i for i, fid in enumerate(face_ids)}
    rej_mask = np.array([fid in rejected for fid in face_ids])

    # ---- iterative expansion ------------------------------------------------
    conf_idx = [pos[f] for f in confirmed if f in pos]
    anchors = np.vstack([ref_embs] + ([E[conf_idx]] if conf_idx else []))
    anchor_score = (E @ anchors.T).max(axis=1)
    refs = anchors.copy()
    is_seed = np.zeros(len(E), bool)
    is_seed[conf_idx] = True
    seed_score = np.zeros(len(E))
    seed_score[conf_idx] = 1.0
    rounds = []
    for rnd in range(1, args.rounds + 1):
        score = (E @ refs.T).max(axis=1)
        cand = ((score >= args.seed) & (anchor_score >= args.anchor) &
                (size >= args.min_seed_size) & (det >= 0.6) & ~rej_mask & ~is_seed)
        n = int(cand.sum())
        rounds.append({"round": rnd, "new_seeds": n, "refs_total": int(len(refs) + n)})
        if n == 0:
            break
        is_seed |= cand
        seed_score[cand] = score[cand]
        refs = np.vstack([refs, E[cand]])

    # Final score: similarity to all references. A seed's own entry would give it
    # 1.0, so seeds keep the score they had when they were accepted.
    final = (E @ refs.T).max(axis=1)
    final[is_seed] = seed_score[is_seed]

    # ---- tiers per face -----------------------------------------------------
    tier = np.full(len(E), "", dtype=object)
    for i, fid in enumerate(face_ids):
        s = final[i]
        if fid in confirmed:
            tier[i] = "match"
        elif fid in rejected:
            tier[i] = ""
        elif fid in unsure:
            tier[i] = "to_check"
        elif s >= args.match and not (size[i] < 40 and s < args.match + 0.08):
            tier[i] = "match"
        elif s >= args.low:
            tier[i] = "uncertain"
    rank = {"match": 3, "to_check": 2, "uncertain": 1, "": 0}

    # ---- per photo (dedupe identical files by sha1) ------------------------
    best = {}
    for i, r in enumerate(rows):
        if not tier[i]:
            continue
        key = r["sha1"] or r["local_path"]
        cur = best.get(key)
        if cur is None or (rank[tier[i]], final[i]) > (rank[tier[cur]], final[cur]):
            best[key] = i
    dup_paths = {}
    for r in con.execute("SELECT sha1, device_path, local_path FROM files WHERE sha1 IS NOT NULL"):
        dup_paths.setdefault(r[0], []).append(r[1] or r[2])

    photos = []
    for key, i in best.items():
        r = rows[i]
        photos.append({
            "tier": tier[i], "score": round(float(final[i]), 3), "face_id": int(r["face_id"]),
            "decided": ("confirmed" if r["face_id"] in confirmed else
                        "unsure" if r["face_id"] in unsure else None),
            "seed": bool(is_seed[i]), "face_px": int(size[i]),
            "local_path": r["local_path"], "device_path": r["device_path"], "sha1": r["sha1"],
            "other_copies": [p for p in dup_paths.get(r["sha1"], []) if p != (r["device_path"] or r["local_path"])],
        })
    photos.sort(key=lambda p: (-rank[p["tier"]], -p["score"]))
    counts = {t: sum(1 for p in photos if p["tier"] == t) for t in ("match", "uncertain", "to_check")}

    # ---- review sheets ------------------------------------------------------
    sheets_dir = os.path.join(work, "sheets")
    for f in os.listdir(sheets_dir):
        os.remove(os.path.join(sheets_dir, f))
    rowmap = {r["face_id"]: r for r in rows}

    def sheets(kind, items, title):
        out = []
        per = 24
        for k in range(0, len(items), per):
            chunk = items[k:k + per]
            path = os.path.join(sheets_dir, f"{kind}_{k // per + 1:02d}.jpg")
            make_sheet([(f"#{p['face_id']}  {p['score']:.2f}", crop_for(rowmap[p["face_id"]])) for p in chunk],
                       path, title=f"{title}  ({k + 1}-{k + len(chunk)} of {len(items)})",
                       ref_crops=ref_crops)
            out.append(path)
        return out

    review_uncertain = [p for p in photos if p["tier"] == "uncertain"]
    review_weak = [p for p in photos if p["tier"] == "match" and not p["decided"]
                   and p["score"] < args.check_below]
    review_weak.sort(key=lambda p: p["score"])
    all_matches = [p for p in photos if p["tier"] == "match"]
    # Near misses: best faces just below --low. People looking down / turned away
    # score low even when it is them, so these get one quick look.
    shown_files = {p["local_path"] for p in photos}
    near, seen = [], set()
    for i in np.argsort(-final):
        r = rows[i]
        if final[i] < args.near_floor or len(near) >= args.near_max:
            break
        if tier[i] or r["face_id"] in rejected or r["local_path"] in shown_files or r["local_path"] in seen:
            continue
        seen.add(r["local_path"])
        near.append({"face_id": int(r["face_id"]), "score": round(float(final[i]), 3)})
    sheet_files = {
        "uncertain": sheets("uncertain", review_uncertain, "UNCERTAIN - is this the reference person?"),
        "weak_matches": sheets("weak_matches", review_weak, "WEAKER MATCHES - spot-check"),
        "near_misses": sheets("near_misses", near, "NEAR MISSES - below threshold; any hidden/turned-away faces of the person?"),
        "all_matches": sheets("all_matches", all_matches, "ALL MATCHES"),
    }

    result = {
        "name": meta.get("name"), "refs": meta.get("refs"), "counts": counts,
        "faces_in_index": int(len(E)), "rounds": rounds,
        "params": {k: getattr(args, k) for k in ("match", "low", "seed", "anchor", "check_below")},
        "decisions": dec, "to_review": {"uncertain": len(review_uncertain), "weak_matches": len(review_weak)},
        "sheets": sheet_files, "notes": notes, "photos": photos,
    }
    save_json(os.path.join(work, "results.json"), result)

    print(json.dumps({k: result[k] for k in ("name", "counts", "faces_in_index", "rounds", "to_review",
                                              "sheets", "notes")}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
