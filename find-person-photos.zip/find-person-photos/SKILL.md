---
name: find-person-photos
description: Find every photo on the user's own computer that shows a specific person, recognised by face from a reference photo (photos have no alt text or tags), and copy the matches into a new folder named after that person. Use whenever the user sends or points to a photo of someone and asks to find, collect or gather the photos that person appears in, alone or in a group, e.g. "იპოვნე ირაკლი", "მოძებნე ლაშა ბაქრაძე", "მოძებნე ყველა ფოტო სადაც ეს ადამიანია", "find all pictures of this doctor on my computer", "collect Nino's photos into a folder". Also use for follow-ups like "now find Giorgi too" in the same session.
---

# Find a person's photos on the user's computer

The user sends one photo of a person and a name. Search the photos in their computer folders (Desktop, Documents, Downloads, Pictures by default), find every image where that person's face appears, alone or in a group, and copy those images into a new folder named after the person. The default location for that folder is the Desktop.

The photos have no tags, so the search is by face. A face-recognition model (InsightFace ArcFace) runs in the cloud workspace and does the bulk comparison. You then check the borderline cases by eye. The model is fast and consistent across thousands of photos. Your eyes are better on the few cases the model can't call, and every face you confirm becomes an extra reference that helps the next pass.

Talk to the user in their language (usually Georgian). Keep updates short: what you're doing, how many photos, how long it will take.

## How the files flow

The user's computer (Windows) is reached through the device bridge. No shell runs on it, so photos are **staged** into the workspace, processed there, and the matches are **committed** back:

```
computer folders --device_stage_files--> /mnt/user-data/uploads/<FolderName>/...
                                          | index_faces.py -> find_person.py -> visual review
/mnt/user-data/outputs/<name>/  <--export_matches.py
        --device_commit_files--> C:\Users\<user>\Desktop\<name>\
```

The helper scripts live on the user's computer in `Documents\claude-skills\find-person-photos\scripts\` (step 3 fetches them). Use one working directory per session, `W=/home/claude/face-search`. The face index (`$W/index.db`) is reused for later searches in the same session, so a second person ("now find Giorgi") skips straight to step 6.

## Workflow

Track these steps in the task list. The run can take a while, and the list is how the user follows progress.

### 1. Collect the inputs

- **Reference photo.** This is usually attached in chat. Look under `/mnt/user-data/uploads/`, or use the attachment path given with the message. If the user names a file on their computer, stage it. If they give several photos of the person, use all of them (repeat `--ref`). More angles mean better recall.
- **Name.** This is the person's name from the request ("მოძებნე ლაშა ბაქრაძე" → `ლაშა ბაქრაძე`), used as the folder name exactly as written. If there's no name, ask once. If nobody is there to answer, use `ნაპოვნი ფოტოები`.
- **Scope.** Search the folders the user names. If they name none, search Desktop, Documents, Downloads and Pictures.

### 2. Get folder access

Call `get_device_info`. If a folder you need is not in `connectedFolders`, request all the missing ones in **one** `device_request_folder_access` call (e.g. `["~/Desktop","~/Documents","~/Downloads","~/Pictures"]`) with a short reason.

Always include `~/Documents`, because the scripts live there, even if the user doesn't want Documents searched. The granted result gives the absolute Windows paths (e.g. `C:\Users\name\Desktop`). Keep them, because they are needed for indexing and for writing results back.

### 3. Fetch the scripts, set up, check the reference

Stage these files in one `device_stage_files` call:

```
C:\Users\<user>\Documents\claude-skills\find-person-photos\scripts\{setup.sh, face_engine.py, index_faces.py, find_person.py, export_matches.py, pick_images.py}
```

Then run:

```bash
W=/home/claude/face-search; S=$W/scripts; mkdir -p $S
cp /mnt/user-data/uploads/Documents/claude-skills/find-person-photos/scripts/* $S/
bash $S/setup.sh          # installs onnxruntime if missing, downloads the face models (~5 s)
python3 $S/find_person.py --db $W/index.db --work "$W/search-<name>" --name "<name>" --ref <reference> --check-ref
```

If the scripts folder is missing, tell the user the skill's scripts were moved or deleted from `Documents\claude-skills` and need to be restored before the search can run.

Read the `ref_crop_1.jpg` the check prints so you know whose face you're looking for. If the output contains:
- `NO_FACE`: ask the user for a photo where the face is clearly visible.
- `MULTIPLE_FACES`: view `ref_faces_1.jpg`. If the user didn't say which person they mean, ask, then re-run with `--ref-face N`.
- `SMALL_REF_FACE`: carry on, but mention that a closer photo would improve results.

### 4. List and stage the photos

For each root, call `device_list_dir(path, recursive=true)`. Send the calls for all roots in one turn.

**Long listings are saved to a file.** The tool then returns an error naming the file. Don't read that file into context. Run the helper on it; it applies all the rules below and prints ready-made batches of full paths:
```bash
python3 $S/pick_images.py --listing <saved file> --root "C:\Users\name\Downloads" [--skip-dir "<name>"]
```

For short listings shown inline, pick the files by hand using the same rules:
- Keep image extensions: `.jpg .jpeg .jfif .png .webp .bmp .tif .tiff .gif .heic .heif .avif`.
- Also keep files with **no extension** between 3 KB and 20 MB. People often save web images without one (e.g. a doctor's photo saved as `eka uglava`). Non-images among them are skipped harmlessly during indexing.
- Skip files under 3 KB.
- Skip these folders: `AppData`, `node_modules`, `.git`, `$RECYCLE.BIN`, `claude-skills`, hidden folders, and earlier result folders (e.g. `Desktop\<name>`).
- If an entry is `depthCapped`, list that subfolder separately. If the result says `truncated`, list the subfolders one at a time.
- Skip `cloudOnly` files, because staging them would download them from OneDrive. Count them and tell the user at the end; stage them only if the user wants.

Tell the user how many photos you found and roughly how long it will take: about 0.5 s per photo to index, plus staging.

Stage with `device_stage_files`: at most 50 paths and 500 MB per call. Send several calls in one turn. Files land at `/mnt/user-data/uploads/<root folder name>/<relative path>`; e.g. `C:\Users\name\Desktop\sanagve\a.jpg` → `/mnt/user-data/uploads/Desktop/sanagve/a.jpg`. If the photo count runs into the tens of thousands, ask the user to narrow the scope (e.g. a specific event folder) first.

### 5. Index the faces

```bash
U=/mnt/user-data/uploads; H='C:\Users\name'
python3 $S/index_faces.py --db $W/index.db \
  --root "$U/Desktop=$H\\Desktop" --root "$U/Pictures=$H\\Pictures" \
  --root "$U/Documents=$H\\Documents" --root "$U/Downloads=$H\\Downloads"
```

Use one `--root LOCAL=DEVICE` per searched folder. `LOCAL` is the staged copy and `DEVICE` is the real path; the mapping is how each photo's original location is remembered.

Indexing is incremental and checkpoints every 25 photos, and already indexed files are skipped. You can start it while staging continues, then run it again to pick up new files.

Above ~600 photos, the run won't finish within a command timeout. Start it with `nohup ... > $W/index.log 2>&1 &` and check `tail -2 $W/index.log`. Unreadable and non-image files are logged and skipped.

### 6. Search

```bash
python3 $S/find_person.py --db $W/index.db --work "$W/search-<name>" --name "<name>" --ref <reference>
```

The search compares every face with the reference. Faces that match very strongly (score ≥ 0.50, still resembling the original reference) become extra references, and the search repeats until nothing new turns up. This is how one photo grows into a profile of the person across angles, lighting and years.

The output gives `counts`, `to_review`, and `sheets` (contact-sheet images with face IDs and scores; the reference is shown top-left in green). Per-photo details are in `results.json` in the work folder.

Score guide for this model (cosine similarity):
- **≥ 0.50**: almost certainly the same person.
- **0.42–0.50**: very likely. Tiny faces under 40 px in this band are put in "uncertain" instead.
- **0.26–0.42** (the "uncertain" tier): could be them, a sibling or a look-alike, or a poor-quality face. This band is what needs your eyes.
- **Strangers** usually score below 0.20.

### 7. Check the borderline faces visually

This is the step that makes the result trustworthy, so don't skip it.

1. `Read` every `uncertain_*.jpg` and `weak_matches_*.jpg` sheet. Also look at `near_misses_*.jpg`. It shows the best faces just below the threshold, because someone looking down, turned away or wearing a mask scores low even when it is them. If there are about 150 matches or fewer, also skim the `all_matches_*.jpg` sheets for an obvious intruder.
2. For each face, compare it with the green REFERENCE using features that stay stable: head and face shape, eye shape and spacing, eyebrows, nose, mouth, jawline and chin, ears, hairline or baldness pattern. Hair colour or style, beards, glasses, make-up, clothes and age change between photos and shouldn't decide anything.
3. If a crop is too small or blurry to judge, `Read` the full photo (`local_path` in results.json) before deciding. For a face in a big photo, crop and enlarge that region with PIL first.
4. Feed the decisions back. Use face IDs from the sheets; they can be passed with or without `#`:
   ```bash
   python3 $S/find_person.py --db $W/index.db --work "$W/search-<name>" --confirm 12,40 --reject 7,19 --unsure 33
   ```
   Decisions accumulate in `decisions.json`. Confirmed faces become references, so a re-run may surface new candidates.
5. Repeat until `to_review.uncertain` and `to_review.weak_matches` are both 0 and the near misses have been looked at.

How to decide:
- Mark `--unsure` only when the face is truly impossible to judge (e.g. tiny, turned away, heavily blurred) but could be the person. Unsure photos go into a subfolder for the user to decide.
- A high model score with a different hairstyle is still a match. Don't reject strong scores on surface differences.
- In the uncertain band, what can cause a wrong call is a relative or someone of similar age and build. Look at the features.

### 8. Copy the results to the computer

Check whether `Desktop\<name>` already exists (`device_list_dir` on the Desktop, non-recursive). If it does, use `<name> (2)` so earlier results are never overwritten. Then:

```bash
python3 $S/export_matches.py --work "$W/search-<name>" --device-dest 'C:\Users\name\Desktop\<name>'
```

This copies the matches to `/mnt/user-data/outputs/<name>/`. Unsure and remaining uncertain photos go to the subfolder `გადასამოწმებელი` ("to double-check"); pass `--no-check-folder` to leave them out. Identical copies of the same image are included once.

It writes `commit_batches.json`. Send each batch with `device_commit_files` (`files` = that batch's `{stagedPath, devicePath}` list). The destination folder and subfolder are created automatically. If `missing_staged_copies` is not empty, re-stage those paths and run the export again.

### 9. Report back

In a few lines in the user's language, say:
- how many photos were found and where the folder is, in plain words ("Desktop-ზე, საქაღალდე „ლაშა ბაქრაძე“");
- how many photos are in `გადასამოწმებელი` and why (e.g. "the face is turned away");
- anything skipped: OneDrive cloud-only files, unreadable files, folders you didn't search.

Send `all_matches_01.jpg` with `SendUserFile` so they can see the result at a glance. Don't recap the steps.

## Limitations

Mention these only when they matter:
- The face must be visible. People seen from behind, in full profile or looking down are often missed; the near-miss sheet catches some of them.
- Faces smaller than about 25 px, e.g. at the back of a large crowd, are unreliable.
- Videos are not searched, only images.
- Identical twins can't be told apart.

## Privacy

The face index holds face data for everyone in the user's photos. Keep it in the session workspace only. It disappears with the session. Don't copy it to the user's computer, to memory, or anywhere else unless they ask. Search only the folders the user granted.
