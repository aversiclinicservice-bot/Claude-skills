# claude-skills

Aversi Clinic-ის Claude სქილები: Nova CMS-ში კონტენტის თარგმნა (KA → EN), შიდა ლინკების გასწორება და ექიმების ინგლისური სახელები.

| სქილი | აღწერა |
|---|---|
| [`nova-ka-en-translator`](skills/nova-ka-en-translator/SKILL.md) | Translate Aversi Clinic Nova CMS content (blogs, lab analyses, services, pages) from Georgian to English: title, HTML content, meta and slug, saved straight into Nova. |
| [`nova-internal-link-fixer`](skills/nova-internal-link-fixer/SKILL.md) | After translating Aversi Clinic blogs, fix internal links in Nova: point EN content to /en pages, repair legacy /news, /eqimi, /service and relative links, and refresh doctor URLs. |
| [`nova-doctor-en-names`](skills/nova-doctor-en-names/SKILL.md) | Add or fix English (Latin) names for Aversi Clinic doctors in Nova using Georgian national transliteration, plus empty meta titles and descriptions. |

## გამოყენების თანმიმდევრობა
1. `nova-ka-en-translator` – თარგმნა და Nova-ში შენახვა
2. `nova-doctor-en-names` – ექიმების ლათინური სახელები და მეტა
3. `nova-internal-link-fixer` – შიდა ლინკების გასწორება და ხელახალი შემოწმება

## ინსტალაცია
თითოეული საქაღალდე `skills/<name>/` არის ცალკე სქილი. Claude-ში დაამატე Settings → Capabilities → Skills (ატვირთე საქაღალდე zip-ად), ან Claude Code-ში დააკოპირე `~/.claude/skills/`-ში.
