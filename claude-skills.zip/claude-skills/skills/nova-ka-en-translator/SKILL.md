---
name: nova-ka-en-translator
description: Translate Aversi Clinic Nova CMS content (blogs, lab analyses, services, pages) from Georgian to English: title, HTML content, meta and slug, saved straight into Nova.
---

# Nova თარჯიმანი (KA → EN)

აავსებს ინგლისურ ვერსიას Nova-ში (dashboard.aversiclinic.ge) ქართული ტექსტის საფუძველზე. მუშაობს Claude in Chrome-ით, მომხმარებლის შესულ სესიაში.

## როდის გამოიყენო
- „თარგმნე ბლოგები / ლაბორატორიული ანალიზები / სერვისები ინგლისურად“
- „რომელ ჩანაწერებს არ აქვს EN ვერსია?“
- ახალი ბლოგის გამოქვეყნების შემდეგ EN ვერსიის დამატება

## ეტაპი 1. მომზადება
1. გახსენი dashboard.aversiclinic.ge ტაბში (მომხმარებელი უკვე შესულია; პაროლს არასდროს შეიყვან).
2. დაადგინე რესურსი: `blogs`, `laboratory-services`, `services`, `pages` და ა.შ.
3. ჩანაწერის მონაცემების წაკითხვა:
   `GET /nova-api/{resource}/{id}/update-fields?editing=true&editMode=update` (header `Accept: application/json`).
   - ველები შეიძლება იყოს `fields` მასივში ან ობიექტში; `nova-tab-translatable` კომპონენტის შიგნით არის `fields` სია.
   - თარგმნადი ველები: `translations_{field}_{ka|en|ru}`, მაგ. `translations_title_ka`, `translations_content_ka`, `translations_slug_ka`, `translations_name_ka`, `translations_meta_title_ka`, `translations_meta_desc_ka`.

## ეტაპი 2. რა სჭირდება თარგმანს (სიის შედგენა)
1. გადაიარე ყველა ID (სიის გვერდებიდან ან ცნობილი დიაპაზონიდან).
2. ჩანაწერი სათარგმნია, თუ `*_en` ცარიელია ან ქართული ასოები აქვს (`/[Ⴀ-ჿ]/`).
3. გამოტოვე: მხოლოდ სურათებიანი ჩანაწერი (ტექსტი არ აქვს), სატესტო ჩანაწერები (`test`), არამედიცინური დუბლიკატები. ჩაინიშნე მიზეზი.
4. მომხმარებელს აჩვენე რაოდენობა და დაიწყე.

## ეტაპი 3. თარგმნა (თითო ჩანაწერზე)
1. **სათაური (title/name):** ბუნებრივი, SEO-სთვის გამართული ინგლისური; სამედიცინო ტერმინი სტანდარტული ფორმით (მაგ. „ჭინჭრის ციება“ → Urticaria (Hives)).
2. **კონტენტი (HTML):**
   - თარგმნე მხოლოდ ტექსტური კვანძები. HTML სტრუქტურა, ტეგები, `style`, `class`, სურათები, ცხრილები, სიები უცვლელად დატოვე.
   - `href`-ები არ შეცვალო თარგმნისას (ლინკების გასწორება ცალკე ეტაპია, იხ. nova-internal-link-fixer).
   - ანკორის ტექსტი თარგმნე.
   - ექიმების სახელები: ლათინური ტრანსლიტერაცია (იხ. nova-doctor-en-names).
   - ციფრები, ერთეულები, დოზები, ანალიზის კოდები (მაგ. L2120) ზუსტად შეინარჩუნე.
   - არ დაამატო და არ ამოიღო შინაარსი; ტონი: ინფორმაციული, პაციენტისთვის გასაგები.
3. **მეტა ველები:**
   - `meta_title_en`: ≤ 60 სიმბოლო, მთავარი ტერმინით.
   - `meta_desc_en`: 140–160 სიმბოლო, „at Aversi Clinic“ საჭიროების შემთხვევაში.
4. **Slug:** `translations_slug_en` = `translations_slug_ka` (EN slug-ს ქართულის ტოლს ვტოვებთ, რომ URL-ები ემთხვეოდეს).
5. RU ველებს არ ვეხებით, თუ ცალკე არ მოითხოვეს.

## ეტაპი 4. შენახვა Nova-ში
1. ააწყე `FormData` იმავე ველებით, რაც update-fields-მა დააბრუნა:
   - text / slug / tinymce → `value` (null → `''`)
   - belongs-to → `attr = belongsToId` და `attr_trashed = false`
   - boolean → `1`/`0`
   - multiselect → `attr[0]`, `attr[1]`… ან `''` თუ ცარიელია
   - file ველები გამოტოვე (ფოტო არ იცვლება)
   - flexible content (მაგ. ექიმის `additional->ka`) → JSON სერიალიზაცია; თუ ფორმატი გაურკვეველია, შეინახე UI-ით.
2. დაამატე `_method=PUT`, `_retrieved_at=<unix წამები>`.
3. `POST /nova-api/{resource}/{id}?editing=true&editMode=update`, headers: `X-XSRF-TOKEN` (cookie-დან, decodeURIComponent), `X-Requested-With: XMLHttpRequest`, `Accept: application/json`.
4. 422 შეცდომა = ვალიდაცია (ხშირად სავალდებულო `meta_title_ka`/`meta_desc_ka` ან slug). შეავსე და გაიმეორე.
5. თუ ერთი ჩანაწერი ძალიან დიდია და სერვერი action_events ზომის ლიმიტზე აგდებს, ჩაინიშნე და მომხმარებელს შეატყობინე (ხელით შენახვა სჭირდება).

## ეტაპი 5. შემოწმება
1. ხელახლა წაიკითხე update-fields: EN ველები სავსეა, ქართული ასოები არ არის, KA ველები უცვლელია.
2. საჯარო API-თი შეამოწმე: `/api/blog/{id}/en`, `/api/lab_analysis/{id}/en`, `/api/service/{slug}/en`.
3. Action log-ში (`/nova-api/action-events`) ცვლილება მხოლოდ თარგმნილ ველებს უნდა ეხებოდეს.

## ეტაპი 6. ანგარიში
ქართულად, მოკლედ: რამდენი ითარგმნა, რომელი გამოიტოვა და რატომ, რომელი ვერ შეინახა. შემდეგი ნაბიჯი: nova-internal-link-fixer.

## ტექნიკური შენიშვნები
- javascript_tool-ის შედეგი იბლოკება, თუ შეიცავს `?`, `&`, `=` ან cookie-ს. გრძელ შედეგს ჩაწერე `<pre>`-ში ან localStorage-ში და წაიკითხე get_page_text-ით.
- ფონურ ტაბში ტაიმერები ნელდება; ხანგრძლივი ციკლი გაუშვი async-ად, პროგრესი localStorage-ში შეინახე და შუალედურად screenshot გადაიღე.
- სრული ნავიგაცია შლის window ცვლადებს; მდგომარეობა localStorage-ში შეინახე.
- თითო ჩანაწერი ცალკე შეინახე და შეამოწმე, რომ შეცდომა ერთზე შეჩერდეს.
