---
name: nova-doctor-en-names
description: Add or fix English (Latin) names for Aversi Clinic doctors in Nova using Georgian national transliteration, plus empty meta titles and descriptions.
---

# ექიმების ინგლისური სახელები (Nova)

## როდის გამოიყენო
- „ექიმებს აკლიათ ინგლისური სახელები“
- EN საიტზე ექიმის სახელი ქართული ასოებით ჩანს
- ბლოგში ექიმის ლინკის სახელის გასწორებამდე

## ეტაპი 1. სიის შედგენა
1. `GET /api/doctors/en?page=N` (`max_pages`-მდე) ან Nova-დან: ექიმები, რომელთა `translations_name_en` ცარიელია ან ქართულ ასოებს შეიცავს.
2. შეინახე სია localStorage-ში: `[id, enName, kaName, {ცარიელი meta ველები}]`.

## ეტაპი 2. ტრანსლიტერაცია (ქართული ეროვნული სისტემა)
ა a, ბ b, გ g, დ d, ე e, ვ v, ზ z, თ t, ი i, კ k, ლ l, მ m, ნ n, ო o, პ p, ჟ zh, რ r, ს s, ტ t, უ u, ფ p, ქ k, ღ gh, ყ q, შ sh, ჩ ch, ც ts, ძ dz, წ ts, ჭ ch, ხ kh, ჯ j, ჰ h.
- ყოველი სიტყვა დიდი ასოთი (ასევე `-` და `(`-ის შემდეგ).
- რიგი: სახელი გვარი (Nova-ში თუ „გვარი სახელი“ წერია, გადაატრიალე, მაგ. „ქოიავა გელა“ → Gela Koiava).
- „პროფესორი“ → Professor.
- თუ ექიმს დადგენილი ლათინური ფორმა აქვს (პასპორტი, მომხმარებლის მითითება, მაგ. Marina Machaidze), ის გამოიყენე.
- RU სახელი მხოლოდ მომხმარებლის მოთხოვნით (მაგ. Марина Мачаидзе).

## ეტაპი 3. მეტა ველები (მხოლოდ თუ ცარიელია)
- `meta_title_ka` = ქართული სახელი; `meta_desc_ka` = „{სპეციალობა} {სახელი} ავერსის კლინიკაში“
- `meta_title_en` = EN სახელი; `meta_desc_en` = „{Specialty} {Name} at Aversi Clinic“
(KA მეტა სავალდებულოა, მის გარეშე 422 შეცდომა მოდის.)

## ეტაპი 4. შენახვა
- ექიმის ფორმაში არის flexible content (`additional->ka/en/ru`, ჩადგმული სექციებით) და multiselect-ები (branch_ids, specialty_ids, languages, ap_service_ids).
- API-ით შენახვისას ააწყე FormData ზუსტად ისე, როგორც Nova UI: multiselect → `attr[i]`; `___nova_flexible_content_fields` = JSON სია; flexible მნიშვნელობა = `[{layout,key,attributes:{"{key}__{attr}": value, ...}}]`, ჩადგმულ ჯგუფში დამატებით `___nova_flexible_content_fields`. სერიალიზაცია ჯერ ერთ ექიმზე შეადარე UI-ის რეალურ მოთხოვნას (XHR hook) და მხოლოდ ზუსტი დამთხვევის შემდეგ გაუშვი ყველაზე.
- ფოტოს ველი (file) არ გაგზავნო.
- ალტერნატივა: UI ავტომატიზაცია (ID-ები `translations_name_en-default-text-field`, ღილაკი „განაახლე ექიმი“), ერთი ექიმი ერთ ციკლში.

## ეტაპი 5. შემოწმება
1. `/api/doctor/{id}/en` → სახელი ლათინურია და ემთხვევა სიას.
2. სხვა ველები (ფოტო, ფილიალები, სპეციალობები, სექციები) არ შეცვლილა; action-events-ში ცვლილება მხოლოდ name/meta ველებზეა (ცარიელი ap_service_ids → [] ნორმალურია).
3. ამის შემდეგ ბლოგებში ექიმის URL-ები განაახლე (nova-internal-link-fixer).

## ეტაპი 6. ანგარიში
ქართულად: რამდენ ექიმს დაემატა სახელი, რომლებზე იყო გამონაკლისი, რომელი ვერ შეინახა.
