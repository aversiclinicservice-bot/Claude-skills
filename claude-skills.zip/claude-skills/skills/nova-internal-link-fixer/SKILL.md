---
name: nova-internal-link-fixer
description: After translating Aversi Clinic blogs, fix internal links in Nova: point EN content to /en pages, repair legacy /news, /eqimi, /service and relative links, and refresh doctor URLs.
---

# შიდა ლინკების გასწორება (Nova, KA/EN)

## როდის გამოიყენო
- ბლოგების თარგმნის შემდეგ (EN ტექსტში ქართულ გვერდზე მიმავალი ლინკები)
- „გაასწორე შიდა გადალინკვები“, „გატეხილი ლინკები ბლოგებში“
- ექიმის სახელის ან სერვისის slug-ის შეცვლის შემდეგ

## ეტაპი 1. აუდიტი (არაფერს ცვლის)
1. ყველა ბლოგის `translations_content_ka/en` წაიკითხე update-fields-ით.
2. ამოიღე ყველა `<a href>` და დაალაგე ტიპებად:
   - `blog/{page}/{id}/{slug}` → ბლოგი (იტვირთება ID-ით, მე-3 სეგმენტი)
   - `services/{slug}` → სერვისი
   - `doctors/{page}/doctor/{id}/{name}` → ექიმი
   - `lab/analysis/{id}`, `laboratory-analysis/{id}` → ანალიზი
   - `technology/{slug}` → ტექნოლოგია
   - ძველი: `/news/{id}`, `/eqimi/{id}`, `/service/{id}`, `/44/...`, `../../../../...`
   - გარე ლინკები ცალკე
3. ვალიდაცია API-თ (საჯარო გვერდები SPA-ა და ყოველთვის 200-ს აბრუნებს): `/api/blog/{id}/{lang}`, `/api/service/{slug}/{lang}`, `/api/doctor/{id}/{lang}`, `/api/lab_analysis/{id}/{lang}`. ვალიდაციის გასაღები = `key|lang`.
4. შედეგი მომხმარებელს: რამდენი და რა ტიპის პრობლემაა. გაურკვეველი შემთხვევები (წაშლილი ექიმი, უცნობი ძველი ID) წინასწარ ჰკითხე.

## ეტაპი 2. გასწორების წესები
1. **EN ტექსტი → EN გვერდი:** შიდა ლინკს `/en`-ის გარეშე დაამატე `/en` (`https://aversiclinic.ge/en/...`).
2. **სერვისები:** EN-ში გამოიყენე EN slug, თუ განსხვავდება (rentgenologia→radiology, stomatologia→dentistry, psikoterapia→psychotherapy, ortopedia-travmatologia→orthopedics-traumatology, onkologia→oncology, neirokirurgia→neurosurgery, revmatologia→rheumatology, proktologia→proctology, gamma-knife-gama-naipi→gamma-knife). ID-ით ლინკი (`/services/31`) გადაიყვანე slug-ზე.
3. **ძველი `/news/{id}`:** ახალი ბლოგი იპოვე `/api/blog/{id}/ka`-ის `old_slug`-ით (`news/{id}/...`). თუ ვერ მოიძებნა, ჰკითხე მომხმარებელს ან ლინკი მოხსენი (ტექსტი დარჩეს).
4. **ძველი `/eqimi/{id}`:** ძველი→ახალი ექიმის ID-ების რუკით გადაიყვანე. ექიმი საიტზე აღარ არის → ლინკი მოხსენი, ტექსტი დატოვე.
5. **ექიმის URL:** `https://aversiclinic.ge{/en}/doctors/1/doctor/{id}/{სახელი}`. EN-ში სახელი = ექიმის EN სახელი (encodeURIComponent), KA-ში ქართული. ექიმის ლინკები ახალ ტაბში იხსნება (`target="_blank" rel="noopener"`).
6. **ფარდობითი `../` ლინკები:** ჯერ ნორმალიზება `/`-ად, მერე ზემოთა წესები.
7. **წაშლილი ბლოგი:** უახლოეს თემატურ ბლოგზე გადაიყვანე (მომხმარებელთან შეთანხმებით).
8. **გაფუჭებული markdown href** (`[https:/x](https:/x)`) → `https://x`.
9. მოუხსნელი BMI/ძველი ხელსაწყოს ლინკი → მოხსენი ლინკი, ტექსტი დატოვე.

## ეტაპი 3. შენახვა
1. ჯერ dry-run: თითო ბლოგზე ცვლილებების ლოგი (`ძველი → ახალი`) და მომხმარებლისთვის ჯამი.
2. შენახვა იგივე FormData მეთოდით, რაც nova-ka-en-translator-ში; იცვლება მხოლოდ `translations_content_*`.
3. პირველი ბლოგის შემდეგ action-events-ში შეამოწმე, რომ შეიცვალა მხოლოდ `content`.

## ეტაპი 4. ხელახალი სკანირება
ყველა ბლოგი თავიდან გადაამოწმე: 0 `eqimi`, 0 `/news/`, 0 `../`, 0 `https:/x`, EN ტექსტში 0 ქართულ გვერდზე მიმავალი შიდა ლინკი.

## ეტაპი 5. ანგარიში და ანალიტიკა
ქართულად: რამდენი ლინკი გასწორდა რამდენ ბლოგში, რა მოიხსნა და რატომ, რა დარჩა (მაგ. RU ვერსია). საჭიროებისას განაახლე შიდა ლინკების მონიტორის დაფა (Artifact).
